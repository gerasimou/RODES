Cluster results
---------------
Evaluations:	10000

Population:  	20

Model:       	clusterTemplate2.sm

Properties:  	cluster.csl

Sensitivity:	YES

Tolerance:		0.01, 0.015, 0.02, 0.025